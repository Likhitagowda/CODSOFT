import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class Course {
    String code;
    String title;
    String description;
    int capacity;
    String schedule;
    int enrolled;

    Course(String code, String title, String description, int capacity, String schedule) {
        this.code = code;
        this.title = title;
        this.description = description;
        this.capacity = capacity;
        this.schedule = schedule;
        this.enrolled = 0;
    }

    boolean isAvailable() {
        return enrolled < capacity;
    }

    void enroll() {
        if (isAvailable()) {
            enrolled++;
        }
    }

    void drop() {
        if (enrolled > 0) {
            enrolled--;
        }
    }

    @Override
    public String toString() {
        return code + ": " + title + " (" + enrolled + "/" + capacity + ") - " + schedule + "\n" + description;
    }
}

class Student {
    String id;
    String name;
    List<Course> registeredCourses;

    Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.registeredCourses = new ArrayList<>();
    }

    void registerCourse(Course course) {
        if (course.isAvailable()) {
            registeredCourses.add(course);
            course.enroll();
        } else {
            System.out.println("Course is full!");
        }
    }

    void dropCourse(Course course) {
        if (registeredCourses.remove(course)) {
            course.drop();
        } else {
            System.out.println("You are not registered in this course!");
        }
    }

    @Override
    public String toString() {
        return id + ": " + name;
    }
}

public class CourseManagementSystem {
    static Map<String, Course> courses = new HashMap<>();
    static Map<String, Student> students = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Sample data
        courses.put("CS101", new Course("CS101", "Intro to Computer Science", "Basics of computer science", 30, "MWF 10-11"));
        courses.put("MATH101", new Course("MATH101", "Calculus I", "Introduction to calculus", 25, "TTh 9-10:30"));

        students.put("S001", new Student("S001", "Alice"));
        students.put("S002", new Student("S002", "Bob"));

        while (true) {
            System.out.println("1. List Courses");
            System.out.println("2. Register for Course");
            System.out.println("3. Drop Course");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    listCourses();
                    break;
                case 2:
                    System.out.print("Enter student ID: ");
                    String studentId = scanner.nextLine();
                    System.out.print("Enter course code: ");
                    String courseCode = scanner.nextLine();
                    registerCourse(studentId, courseCode);
                    break;
                case 3:
                    System.out.print("Enter student ID: ");
                    studentId = scanner.nextLine();
                    System.out.print("Enter course code: ");
                    courseCode = scanner.nextLine();
                    dropCourse(studentId, courseCode);
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }

    static void listCourses() {
        for (Course course : courses.values()) {
            System.out.println(course);
        }
    }

    static void registerCourse(String studentId, String courseCode) {
        Student student = students.get(studentId);
        Course course = courses.get(courseCode);
        if (student != null && course != null) {
            student.registerCourse(course);
        } else {
            System.out.println("Invalid student ID or course code!");
        }
    }

    static void dropCourse(String studentId, String courseCode) {
        Student student = students.get(studentId);
        Course course = courses.get(courseCode);
        if (student != null && course != null) {
            student.dropCourse(course);
        } else {
            System.out.println("Invalid student ID or course code!");
        }
    }
}
