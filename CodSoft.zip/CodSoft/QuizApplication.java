import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

class Question {
    String question;
    String[] options;
    int correctAnswer;

    public Question(String question, String[] options, int correctAnswer) {
        this.question = question;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }
}

class Quiz {
    private Question[] questions;
    private int score;
    private int currentQuestionIndex;
    private Scanner scanner;
    private Timer timer;
    private boolean timeUp;

    public Quiz(Question[] questions) {
        this.questions = questions;
        this.score = 0;
        this.currentQuestionIndex = 0;
        this.scanner = new Scanner(System.in);
        this.timer = new Timer();
        this.timeUp = false;
    }

    public void start() {
        for (currentQuestionIndex = 0; currentQuestionIndex < questions.length; currentQuestionIndex++) {
            askQuestion(questions[currentQuestionIndex]);
        }
        displayResult();
    }

    private void askQuestion(Question question) {
        System.out.println(question.question);
        for (int i = 0; i < question.options.length; i++) {
            System.out.println((i + 1) + ": " + question.options[i]);
        }

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                timeUp = true;
            }
        }, 10000); // 10 seconds timer

        int userAnswer = getUserAnswer();
        timer.cancel();
        timer = new Timer(); // Reset timer for next question

        if (timeUp) {
            System.out.println("Time's up!");
        } else if (userAnswer == question.correctAnswer) {
            System.out.println("Correct!");
            score++;
        } else {
            System.out.println("Incorrect. The correct answer was: " + question.options[question.correctAnswer - 1]);
        }

        timeUp = false;
    }

    private int getUserAnswer() {
        int answer = -1;
        while (!timeUp && (answer < 1 || answer > 4)) {
            System.out.print("Your answer: ");
            if (scanner.hasNextInt()) {
                answer = scanner.nextInt();
            } else {
                scanner.next(); // Clear invalid input
            }
        }
        return answer;
    }

    private void displayResult() {
        System.out.println("Quiz Over!");
        System.out.println("Your score: " + score + "/" + questions.length);
        for (int i = 0; i < questions.length; i++) {
            System.out.println("Q" + (i + 1) + ": " + questions[i].question);
            System.out.println("Your answer: " + (i + 1 == questions[i].correctAnswer ? "Correct" : "Incorrect"));
        }
    }
}

public class QuizApplication {
    public static void main(String[] args) {
        Question[] questions = new Question[] {
            new Question("What is the capital of France?", new String[] {"Berlin", "Madrid", "Paris", "Rome"}, 3),
            new Question("Which planet is known as the Red Planet?", new String[] {"Earth", "Mars", "Jupiter", "Saturn"}, 2),
            new Question("What is the largest ocean on Earth?", new String[] {"Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"}, 4)
        };

        Quiz quiz = new Quiz(questions);
        quiz.start();
    }
}
